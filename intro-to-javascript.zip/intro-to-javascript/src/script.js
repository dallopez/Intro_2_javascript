document.body.querySelector("#cool").innerHTML="My Name is"
var prompter = prompt("what is your name?");
document.body.querySelector("#lessCool").innerHTML=prompter;

document.body.querySelector("#dope").innerHTML="and my fave color is"
var prompter = prompt("what is your fav color?");
document.body.querySelector("#lessDope").innerHTML=prompter;
